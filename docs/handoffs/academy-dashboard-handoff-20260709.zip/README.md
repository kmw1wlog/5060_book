# 거장문고

5060 세대를 위한 경제·철학 고전 실물 서적 판매 웹사이트입니다.

## 로컬 실행

```bash
npm install
npm run serve
```

브라우저에서 `http://127.0.0.1:5173/`을 엽니다.

대시보드는 `http://localhost:5173/dashboard.html`에서 확인합니다. Kakao Developers에 등록된 로컬 도메인이 `http://localhost:5173`이므로 `127.0.0.1` 대신 `localhost`를 사용합니다.

## 기관 지도 대시보드

대시보드는 정적 배포 파일인 `data/dashboard-data.json`과 `data/dashboard-config.js`를 읽습니다. 배포 전 실데이터를 갱신하려면 아래 순서로 실행합니다.

```bash
npm run data:dashboard
npm run env:audit
npx playwright test tests/dashboard.spec.js --reporter=line
```

현재 연동 범위:

- Kakao Map JavaScript SDK: 배포 도메인에서 실제 지도 렌더링
- Kakao Local REST: 기관 주소 좌표 보강
- VWorld `LT_P_MGPRTFB`: 노인복지시설 실좌표 수집
- 공공데이터포털: 평생학습강좌, 평생교육시설
- KEDI CSV: 평생교육기관 로컬 파일 데이터
- Supabase Management API: PAT 인증 및 조직 수 확인
- Supabase DB: institutions/contacts 스키마, RLS, 데이터 upsert, read-only anon 검증

이메일 발송은 의도적으로 비활성화되어 있습니다. Supabase 프로젝트 생성은 접근 가능한 조직이 여러 개일 때 자동 진행하지 않고 `SUPABASE_ORG_ID`가 명시된 뒤 진행합니다.

## Supabase DB

현재 운영 DB 프로젝트:

- organization: `kmwOrg`
- project: `5060_book-prod`
- project ref: `jgjgwlqfnhxqedpupxek`

스키마는 `supabase/migrations/20260704010000_dashboard_schema.sql`에 있습니다.

DB 동기화와 검증:

```bash
npm run db:sync
npm run db:verify
```

검증 기준:

- `institutions` 775건
- `contacts` 775건
- anon key 읽기 성공
- anon key 쓰기 차단

DB 비밀번호, service role key, PAT는 `.env`/`.env.local`에만 저장하며 커밋하지 않습니다.

## 검증

```bash
npm run test:e2e
npx playwright test tests/dashboard.spec.js --reporter=line
```

Playwright로 랜딩 페이지와 지도 대시보드의 주요 사용자 흐름을 확인합니다.

## GLB 360도 상품 영상 렌더링

`scripts/render_glb_spin.py`는 Blender Python API로 GLB 책 모델을 가져와 중앙 정렬, 크기 정규화, 투명 PNG 시퀀스 렌더링을 수행한 뒤 `ffmpeg`로 GIF, MP4, WebM을 생성합니다. 실행 환경은 Linux를 기준으로 하며, `blender`와 `ffmpeg`가 PATH에 설치되어 있어야 합니다.

기본 출력:

- `output/book_spin/frames/frame_0001.png`부터 시작하는 투명 PNG 시퀀스
- `output/book_spin/book_spin.gif`
- `output/book_spin/book_spin.mp4`
- `output/book_spin/book_spin_alpha.webm`

기본 렌더 설정:

- 24fps, 5초, 120프레임
- 720x720
- 투명 배경
- Eevee Next 또는 Eevee
- 70mm 근처 카메라, 약간 위에서 내려다보는 상품 렌더 구도

Windows PowerShell 실행 예시:

```powershell
Expand-Archive -Path ".\459ee40a-7754-424f-9d90-c4e821fc4d96.zip" -DestinationPath ".\input" -Force
```

```powershell
blender --background --python scripts/render_glb_spin.py -- --input ".\input\base_basic_pbr.glb" --out ".\output\book_spin"
```

여러 GLB 중 첫 번째 파일을 자동 선택하려면 디렉터리를 입력하고 `--auto-select-first`를 추가합니다.

```powershell
blender --background --python scripts/render_glb_spin.py -- --input ".\input" --auto-select-first --out ".\output\book_spin"
```

카메라 구도만 빠르게 확인하려면 첫 프레임만 렌더합니다.

```powershell
blender --background --python scripts/render_glb_spin.py -- --input ".\input\base_basic_pbr.glb" --out ".\output\book_spin_preview" --preview
```

모델이 뒤집혀 보이거나 표지가 정면을 향하지 않으면 축 회전을 보정합니다.

```powershell
blender --background --python scripts/render_glb_spin.py -- --input ".\input\base_basic_pbr.glb" --out ".\output\book_spin" --rotate-x 90 --rotate-z 180
```

Linux에서 실행할 때도 동일한 인자를 사용합니다. 단, 셸 경로 구분자는 `/`를 쓰는 편이 안전합니다.
